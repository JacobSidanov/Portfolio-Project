# Home Page - Jacob Sidanov

A Pen created on CodePen.io. Original URL: [https://codepen.io/JACOB-SIDANOV/pen/mdvaGJq](https://codepen.io/JACOB-SIDANOV/pen/mdvaGJq).

